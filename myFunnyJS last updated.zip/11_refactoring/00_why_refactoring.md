# POURQUOI CE MODULE MÉRITE TON TEMPS : REFACTORING

Personne n'écrit du code parfait du premier coup. Personne. Le code que tu écris aujourd'hui sous pression, avec une deadline qui approche, sera le code que quelqu'un (toi, dans 6 mois) devra comprendre, modifier, et étendre sans tout casser. Le refactoring, c'est l'art de transformer ce code "qui marche" en code "qui dure".

Coder vite et coder durablement, ce ne sont pas les mêmes compétences. Le refactoring, c'est la deuxième.

---

## 1) LE PROBLÈME QUE ÇA RÉSOUT

Du code qui fonctionne aujourd'hui n'est pas automatiquement du code qui restera maintenable demain. Une fonction qui fait 200 lignes et gère 6 responsabilités différentes (god function), une classe qui sait tout faire et que tout le monde doit modifier (god class), des noms de variables comme `data`, `temp`, `x2` : rien de tout ça n'empêche le code de tourner. Mais tout ça rend le code de plus en plus coûteux à faire évoluer.

Le refactoring résout ce problème directement : il s'agit de modifier la structure interne du code sans changer son comportement externe. Le but n'est jamais "ajouter une fonctionnalité", c'est "rendre le code plus facile à comprendre et à modifier", pour que la prochaine fonctionnalité coûte moins cher à ajouter.

Sans refactoring régulier, chaque nouvelle feature devient plus difficile à ajouter que la précédente, parce que le code accumule de la dette technique (le coût caché du code mal structuré qui doit être payé plus tard, avec intérêts).

---

## 2) QUI SOUFFRE QUAND ÇA MANQUE

Le dev qui ne refactore jamais voit son codebase devenir de plus en plus lourd à chaque sprint. Ajouter une feature qui prenait 2 jours en prend maintenant 5, parce qu'il faut d'abord comprendre un enchevêtrement de fonctions trop longues, de dépendances cachées, et de code smells (signes que quelque chose ne va pas structurellement, même si le code tourne) jamais traités.

L'équipe entière en paie le prix : un nouveau dev qui rejoint le projet met des semaines à comprendre un codebase mal structuré, alors qu'un codebase propre se lit en quelques jours. Les bugs se multiplient aussi, parce qu'une god class qui gère 6 responsabilités a 6 fois plus de raisons de casser à chaque modification.

Et le pire scénario : une "réécriture complète" est décidée parce que personne n'ose plus toucher au code existant. C'est souvent un aveu d'échec collectif : le refactoring continu aurait évité d'en arriver là.

---

## 3) OÙ ÇA APPARAÎT DANS UN VRAI SYSTÈME

```
fonction de 200 lignes qui fait tout                      --> long method (code smell) --> découpage en petites fonctions
classe qui connaît trop de choses sur les autres           --> feature envy              --> redistribution des responsabilités
classe qui fait tout dans le système                        --> god class                  --> séparation selon SOLID
code dupliqué à 5 endroits différents                        --> DRY violé                  --> extraction en fonction réutilisable
ajout d'une feature impossible sans casser autre chose         --> couplage fort              --> refactoring vers DIP/SRP
```

Un refactoring bien fait ne se voit pas de l'extérieur : l'utilisateur final ne remarque rien, parce que le comportement reste identique. C'est un investissement invisible pour l'utilisateur, mais payant directement pour l'équipe qui doit continuer à faire évoluer le système.

---

## 4) MODERNE, LEGACY, OU INTEMPOREL ?

Intemporel. Les principes SOLID (cinq principes qui structurent un codebase pour réduire le couplage et faciliter l'évolution) et la détection de code smells ne dépendent d'aucun framework. Que tu codes en JS, en Python, ou dans un langage qui n'existe pas encore, un god class reste un god class, et le problème qu'il pose reste le même.

---

## 5) CE QUI A CHANGÉ AU FIL DES ANNÉES

Avant, refactorer du code sans tests était une pratique courante mais risquée : on changeait la structure "à l'œil", en espérant ne rien casser, et on découvrait les régressions en prod. Avec la généralisation des tests automatisés (`04_testing`), le refactoring est devenu beaucoup plus sûr : tu peux changer la structure interne du code en confiance, parce que la suite de tests te dit immédiatement si tu as cassé un comportement existant.

Les outils ont aussi évolué : les IDE modernes proposent des refactorings automatiques (renommer une variable partout, extraire une fonction) qui auraient pris des heures de recherche manuelle dans du code legacy il y a 15 ans.

---

## 6) NOYAU DUR DU MÉTIER ?

Oui, explicitement : "10 + 11, Design Patterns + Refacto : sans ça, t'es un risque pour ton équipe". `15_architecture_patterns` dépend directement de `10_design_patterns` ET de `11_refactoring` combinés. Tu ne peux pas construire une architecture clean sans savoir identifier et corriger les smells qui s'accumulent dans un système qui grandit.

---

## 7) POURQUOI ÇA MÉRITE ENCORE TON TEMPS DANS 5 ANS

Le code legacy n'est pas une catégorie qui va disparaître : c'est une catégorie qui va grandir, parce que chaque ligne de code écrite aujourd'hui devient potentiellement du legacy demain. La capacité à lire un code existant, identifier ses faiblesses structurelles, et l'améliorer sans le casser, restera une compétence rare et précieuse, peu importe le langage ou l'époque.

---

## CE QUE TU DOIS RETENIR AVANT D'OUVRIR LE CHAPITRE 01

Du code qui marche aujourd'hui n'est pas automatiquement du code qui durera. Ça casse de trois façons sans refactoring : dette technique qui s'accumule, features qui coûtent de plus en plus cher, équipe qui n'ose plus toucher au code existant. Ces principes restent valides peu importe le langage ou le framework.

Maintenant, ouvre `01_clean_code_basics.md`. Et commence à voir ton propre code comme quelqu'un d'autre devra le lire dans 6 mois.

---

## CE MODULE VS LE SUIVANT : FRONTIÈRE AVEC `12_PROBLEM_SOLVING`

Ces deux modules ont l'air proches. Ils ne font pas la même chose.

| Ce module (`11_refactoring`)          | Le suivant (`12_problem_solving`)        |
|---------------------------------------|------------------------------------------|
| Tu as du code existant                | Tu n'as pas encore de code               |
| Tu améliores la structure interne     | Tu conçois la structure avant d'écrire   |
| Le comportement ne change pas         | Tu choisis quel comportement implémenter |
| Outils : SOLID, smells, extraction    | Outils : décomposition, modélisation     |
| Question : "comment améliorer ça ?"   | Question : "comment attaquer ça ?"       |

En pratique : tu fais du `12_problem_solving` avant d'ouvrir l'éditeur. Tu fais du `11_refactoring` après, sur le code livré qui a grossi.

Les deux compétences coexistent dans le quotidien d'un dev. Ce ne sont pas des alternatives : ce sont deux moments différents dans le cycle de vie du code.
