# POURQUOI CE MODULE MÉRITE TON TEMPS : MEMORY & PERFORMANCE

Ton code marche en local avec 10 lignes de données. Il rame en prod avec 100 000. Entre les deux, rien n'a changé dans ta logique : c'est juste que personne n'a jamais regardé ce que ton code coûtait vraiment en mémoire et en CPU.

La performance n'est pas une option qu'on ajoute à la fin. C'est une compréhension qu'on a dès le départ, ou qu'on paie cash plus tard.

---

## 1) LE PROBLÈME QUE ÇA RÉSOUT

JS gère la mémoire pour toi via un garbage collector (GC : ramasse-miettes, le mécanisme qui libère automatiquement la mémoire inutilisée). Ça te libère de la gestion manuelle, mais ça te donne un faux sentiment de sécurité : tu crois que la mémoire "s'occupe d'elle-même" alors qu'une référence oubliée quelque part peut empêcher le GC de libérer un objet pendant des heures, créant une fuite mémoire (memory leak) qui fait grossir ton process jusqu'au crash.

Côté CPU, le problème est différent mais tout aussi sournois : un algorithme en O(n²) (le temps d'exécution explose au carré du nombre d'éléments) tourne instantanément sur 100 éléments et prend 10 secondes sur 100 000. Sans comprendre la complexité algorithmique, tu ne vois jamais venir le mur.

La vraie question que ce module te force à poser : "qu'est-ce que cette ligne de code coûte vraiment, en mémoire et en temps, quand le volume de données monte ?"

---

## 2) QUI SOUFFRE QUAND ÇA MANQUE

Le dev qui ignore la mémoire et la performance livre du code qui fonctionne parfaitement... en démo. Puis l'app grossit, les utilisateurs arrivent, le volume de données explose, et soudain le serveur consomme 4 Go de RAM pour une tâche qui devrait en utiliser 200 Mo. Personne ne comprend pourquoi, parce que personne n'a jamais profilé (mesuré précisément la consommation) le code.

Sur le frontend, c'est pareil : une fuite mémoire dans une SPA (single page application) fait que l'app devient de plus en plus lente à mesure que l'utilisateur navigue, sans jamais recharger la page. L'utilisateur ne sait pas pourquoi son navigateur ralentit : il ferme l'onglet et n'y revient plus.

Le piège de la copie surface/profondeur est différent mais tout aussi discret : un dev qui croit faire une copie profonde (deep copy) d'un objet alors qu'il fait une copie superficielle (shallow copy) va corrompre des données ailleurs dans l'app sans aucun message d'erreur. Pas de crash, pas de log, juste une donnée qui ne correspond plus à ce qu'elle devrait être.

---

## 3) OÙ ÇA APPARAÎT DANS UN VRAI SYSTÈME

```
boucle imbriquée sur une grande liste      --> O(n²)            --> lenteur qui explose avec le volume
listener jamais retiré (event listener)    --> référence bloquée --> fuite mémoire progressive
objet partagé copié en surface             --> shallow copy      --> mutation qui fuit ailleurs
animation ou scroll qui lag                --> Core Web Vitals   --> UX dégradée (LCP, INP, CLS)
budget de performance non respecté en CI   --> régression silencieuse --> app de plus en plus lente
```

Chaque app qui grandit finit par rencontrer ce mur : ce qui fonctionnait à petite échelle ne fonctionne plus à grande échelle. Le seul moyen de le voir venir avant que les utilisateurs le découvrent, c'est de mesurer (profiling) et de comprendre la complexité de ce que tu écris.

---

## 4) MODERNE, LEGACY, OU INTEMPOREL ?

Les principes sont intemporels : la notation Big-O (notation qui décrit comment le temps ou la mémoire évoluent avec la taille des données) décrit un comportement mathématique qui ne change pas avec les frameworks. Les outils de mesure évoluent (DevTools modernes, Lighthouse, profilers intégrés), mais le besoin de comprendre ce que coûte ton code reste constant.

---

## 5) CE QUI A CHANGÉ AU FIL DES ANNÉES

Avant, la performance se mesurait surtout en temps de chargement brut et en taille de bundle. Aujourd'hui, les Core Web Vitals (LCP, INP, CLS : métriques Google qui mesurent la vitesse perçue, la réactivité, et la stabilité visuelle) sont devenus le standard, parce qu'ils mesurent ce que l'utilisateur ressent vraiment, pas juste ce qu'un chronomètre brut indique.

Le profiling a aussi changé d'échelle : avant, on debug avec quelques `console.log` chronométrés. Maintenant, les DevTools modernes permettent de lire un flamegraph (graphique en flammes qui visualise le temps passé dans chaque fonction) et de repérer exactement quelle fonction bouffe le CPU, sans deviner.

La tendance forte : poser un budget de performance dès le départ et le faire respecter automatiquement en CI (intégration continue), plutôt que de constater le problème après coup en prod.

---

## 6) NOYAU DUR DU MÉTIER ?

Indirectement, oui : ce module est un prérequis explicite pour `07_data_structures` ("prérequis : 01_fundamentals + 06_memory_performance/03_complexity"). Tu ne peux pas comprendre pourquoi une hash table bat un tableau pour certaines opérations si tu ne comprends pas déjà la notion de complexité algorithmique. Ce module est le pont obligatoire entre les fondamentaux et tout ce qui touche aux structures de données et aux algorithmes. Il ouvre aussi la porte à `25_observability`, où mesurer et surveiller les performances en prod devient le quotidien.

---

## 7) POURQUOI LES CORE WEB VITALS VIVENT ICI ET PAS DANS 16_WEB_CONCEPTS

Les Core Web Vitals (LCP, INP, CLS) mesurent les conséquences directes de tes décisions techniques de performance. Un LCP lent, c'est souvent un rendu qui bloque parce qu'une ressource est trop grosse en mémoire. Un CLS élevé, c'est une mauvaise gestion des tailles avant et après le chargement. Ce sont des symptômes de perf, pas des concepts web. C'est pour ça qu'ils vivent ici, dans le module qui t'apprend à mesurer et à comprendre ce qui coûte cher : pas dans 16_web_concepts qui traite le protocole et le browser rendering comme des systèmes, pas comme des instruments de mesure.

---

## 8) POURQUOI ÇA MÉRITE ENCORE TON TEMPS DANS 5 ANS

Les machines deviennent plus puissantes, mais les volumes de données augmentent encore plus vite. Un algorithme en O(n²) qui passait avec 10 000 lignes en 2020 devient un problème avec 10 millions de lignes en 2026. La performance n'est jamais "résolue définitivement" par le matériel : elle reste une compétence de compréhension, pas de chance.

---

## CE QUE TU DOIS RETENIR AVANT D'OUVRIR LE CHAPITRE 01

Ton code qui marche en démo peut s'effondrer en prod si personne ne comprend ce qu'il coûte en mémoire et en CPU. La fuite mémoire silencieuse, la complexité qui explose avec le volume, la copie superficielle qui corrompt des données partagées : ces problèmes n'arrivent pas parce que tu codes mal. Ils arrivent parce que tu n'as jamais mesuré.

Maintenant, ouvre `01_gc_basics.md`. Et découvre ce que ton code laisse vraiment traîner en mémoire.
