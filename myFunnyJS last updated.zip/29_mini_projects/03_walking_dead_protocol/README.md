# WALKING DEAD PROTOCOL

Le groupe de Rick Grimes gère un camp : inventaire de ressources, rotations de garde, niveaux de sécurité par périmètre. Le code existe déjà dans `legacy/campV1.js` : écrit en pleine nuit sous pression, une fonction de 300 lignes, des variables globales partout, zéro test. Personne ne sait exactement ce qu'il fait.

Ce projet n'ajoute aucune feature avant d'avoir des tests. Il refactore le legacy étape par étape, jamais d'un bloc, et construit une v2 propre sans jamais toucher au v1.

---

## CE QUE ÇA FAIT

```
$ node src/cli.js status
[CAMP RICK] Alexandria : jour 47
[SECURITE] Périmètre nord : OK | Périmètre sud : ALERTE (niveau 3)
[INVENTAIRE] Nourriture : 14 jours | Munitions : 847 | Médicaments : CRITIQUE (3 unités)
[GARDES] Rotation suivante dans 4h | Poste A : Daryl | Poste B : Michonne

$ node src/cli.js rotate-guards
[ROTATION] Nouvelle rotation : Daryl -> Glenn | Michonne -> Carl
[LOG] Rotation enregistrée à 22:41

$ node src/cli.js consume --resource food --amount 3
[INVENTAIRE] Nourriture : 11 jours restants
[ALERTE] Seuil critique atteint dans 6 jours si consommation constante
```

---

## INSTALLATION

```
Node.js        : v20+
npm            : v10+
Outils externes: Playwright (installé via npm install)
```

```bash
npm install
npx playwright install chromium   # navigateur pour les tests E2E

node src/cli.js status   # interagir avec le camp
npm test                  # tests unitaires + intégration
npm run test:e2e          # tests E2E Playwright
```

Pas de serveur web : le camp se gère en ligne de commande. Playwright teste le CLI via des processus Node enfants, pas via un navigateur.

---

## ARCHITECTURE

```
legacy/
└── campV1.js              # le spaghetti original : JAMAIS modifié, référence comportementale

src/
├── cli.js                  # point d'entrée
├── parser/argsParser.js    # parse process.argv
├── router/commandRouter.js # route vers le bon handler
├── handlers/               # statusHandler, consumeHandler, rotateGuardsHandler, addThreatHandler, resetHandler
├── services/               # inventoryService, guardService, securityService : état pur, zéro fs direct
├── store/fileStore.js      # seul point d'accès au filesystem (fs.promises)
├── alerts/alertService.js  # seuils et alertes
├── workers/threatSimulator.js  # Worker Thread, simulation de vagues de menaces
├── logger/structuredLogger.js  # JSON logging (logs/camp.jsonl)
└── debug/scenarioReplayer.js   # rejoue un état passé depuis les logs

tests/        # unit + intégration
e2e/          # Playwright
mocks/        # fileStore.mock.js, alertService.mock.js
```

Flux d'une commande :

```
node src/cli.js consume --resource food --amount 3
  --> argsParser.parse(process.argv)
  --> commandRouter.route(parsedArgs)
  --> consumeHandler.execute(args)
        --> inventoryService.consume('food', 3)   // état pur, pas de fs ici
              --> fileStore.read / fileStore.write  // c'est le handler qui lit/écrit
              --> alertService.check(updated)
        --> logger.info('consume', { resource: 'food', amount: 3, remaining: 11 })
        --> renderer.print(result)
```

---

## MODULES CRAZYDEVS COUVERTS

| Module | Où ça se voit |
|---|---|
| `04_testing` | `tests/` (unit + intégration), `e2e/` (Playwright), `mocks/` |
| `11_refactoring` | legacy → src/, SOLID appliqué, code smells éliminés |
| `14_runtime_env` | `cli.js` (argv), `fileStore.js` (fs.promises), `threatSimulator.js` (Worker Threads) |
| `31_tools` | `structuredLogger.js` (JSON), `scenarioReplayer.js` (replay de logs) |

---

## RÈGLES NON-NÉGOCIABLES DE CE PROJET

```
1. legacy/campV1.js reste intact, jamais modifié : c'est la référence comportementale
2. Aucune feature sans test rouge écrit avant : red/green/refactor, toujours
3. Les services ne touchent jamais le filesystem directement : ils reçoivent
   un état, retournent un nouvel état. Seul le handler appelle fileStore.
```

---

## DOCUMENTS DU PROJET

```
cahierdescharges.md   --> spécification complète, ordre de construction en 2 phases, cas limites
TDD_JOURNAL.md        --> phase 1 (couvrir le legacy) puis phase 2 (TDD sur la v2)
POSTMORTEM.md         --> différences de comportement entre v1 et v2
ADR/                  --> décisions d'architecture documentées
```
