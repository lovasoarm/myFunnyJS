# Tout le vocabulaire DB en un seul endroit

Le grimoire du module 23. Pas un résumé : la référence complète que tu rouvres quand un terme te bloque, en review de code ou en lisant une doc technique.

---

| Terme | Définition | Code | Analogies |
|-------|------------|------|-----------|
| DB relationnelle | Données rangées en tables avec un schéma fixe et des relations explicites entre elles. | `CREATE TABLE ninjas (id INT, name TEXT);` | classeur à compartiments fixes de Konoha / fiche de mission Prison Break, toujours le même format |
| SQL | Langage standard pour interroger et manipuler une DB relationnelle. | `SELECT * FROM ninjas WHERE id = 1;` | langue commune à toutes les DB relationnelles / les ordres radio entre Chevaliers Garo, même protocole partout |
| SELECT | Instruction pour lire des données, en choisissant les colonnes voulues. | `SELECT id, chakra FROM ninjas;` | demander juste 2 infos sur la fiche de Michael Scofield / extraire 2 stats d'un combattant sans tout le dossier |
| WHERE | Filtre les lignes selon une condition avant de les retourner. | `WHERE rank = 'jonin'` | le tri des Horrors par menace dans Garo / le filtre de Kakashi sur les missions trop dangereuses |
| JOIN | Recolle deux tables séparées via une colonne commune. | `JOIN villages ON ninjas.village_id = villages.id` | relier le dossier d'un prisonnier à son bloc cellulaire / connecter un ninja à son village d'origine |
| INNER JOIN | Garde seulement les lignes qui matchent dans les deux tables. | `INNER JOIN missions ON m.ninja_id = n.id` | seulement les ninjas qui ont une mission active / l'intersection entre les évadés et ceux qui ont un plan |
| LEFT JOIN | Garde toutes les lignes de la table de gauche, même sans match à droite. | `LEFT JOIN missions ON m.ninja_id = n.id` | tous les ninjas du village, mission ou pas / tous les survivants du camp, qu'ils aient une tâche assignée ou non |
| INDEX | Structure annexe qui accélère la recherche sur une colonne. | `CREATE INDEX idx_chakra ON ninjas(chakra_level);` | la table des matières du grimoire des jutsus / le répertoire des fréquences radio de Garo, trié par secteur |
| EXPLAIN | Affiche le plan d'exécution réel choisi par la DB pour une requête. | `EXPLAIN SELECT * FROM missions WHERE id = 1;` | la reconnaissance avant l'assaut de Michael / l'analyse tactique de Kakashi avant un combat |
| Full table scan | La DB lit toutes les lignes d'une table car aucun index ne peut aider. | (visible dans le résultat d'`EXPLAIN` comme `Seq Scan`) | fouiller toute la prison de Fox River cellule par cellule / éplucher tout le bestiaire de Horrors sans filtre |
| GROUP BY | Regroupe les lignes par valeur commune pour appliquer une agrégation. | `GROUP BY village` | classer les ninjas par village d'origine / regrouper les buts du Ballon d'Or par équipe |
| HAVING | Filtre les groupes après agrégation, contrairement à WHERE qui filtre avant. | `GROUP BY village_id HAVING COUNT(*) > 10` | ne garder que les villages avec plus de 10 ninjas actifs / les équipes avec plus de 50 buts sur la saison |
| Transaction | Bloc d'opérations exécutées comme un tout : tout passe, ou rien ne passe. | `BEGIN; ... COMMIT;` | le plan d'évasion de Michael : chaque étape ou rien, pas de demi-mesure / le rituel Garo, complet ou annulé |
| ACID | Garanties d'une transaction fiable : atomicité, cohérence, isolation, durabilité. | (propriété du moteur DB, pas une instruction SQL) | le serment des Chevaliers Garo, incassable / le plan tatoué de Michael, jamais à moitié exécuté |
| Injection SQL | Faille où une entrée non filtrée devient du code SQL exécuté. | `'OR '1'='1` glissé dans un champ texte | T-Bag qui glisse un faux ordre dans le système de la prison / un Horror qui se déguise en humain pour entrer |
| Requête paramétrée | Requête où les valeurs sont séparées du SQL, jamais concaténées en string. | `db.query('... WHERE id = $1', [id])` | le bulletin de vote séparé de l'enveloppe / le badge d'accès vérifié indépendamment du nom annoncé |
| Normalisation | Discipline qui élimine la duplication d'un même fait dans plusieurs tables. | `jutsus` séparé de `ninjas`, référencé par `ninja_id` | un seul registre des Horrors consulté par tous les Chevaliers / une seule liste des évadés, pas une copie par garde |
| Dénormalisation | Duplication volontaire de données pour accélérer la lecture ou figer un historique. | `combats.degats_au_moment_T` copié au moment du coup | la photo du score figée à la mi-temps / le rapport de mission de Garo, figé tel qu'il a été rédigé sur le terrain |
| Clé primaire (Primary Key) | Identifiant unique d'une ligne dans sa propre table. | `id SERIAL PRIMARY KEY` | le numéro de plaque d'immatriculation d'un ninja au bingo / le matricule de prisonnier à Fox River |
| Clé étrangère (Foreign Key) | Référence vers la clé primaire d'une autre table, garantit l'intégrité. | `village_id INT REFERENCES villages(id)` | le renvoi vers le dossier complet du village / le lien obligatoire entre un Chevalier et son armure assignée |
| Table de jointure (junction table) | Table intermédiaire qui gère une relation many-to-many. | `ninja_jutsus(ninja_id, jutsu_id)` | le carnet de qui-connaît-quel-jutsu, sans dupliquer ni les ninjas ni les jutsus / la liste des alliances entre Chevaliers et Horrors traqués |
| NoSQL | Famille de DB qui s'écarte du modèle relationnel strict pour gagner en flexibilité ou en vitesse. | MongoDB, Redis, Cassandra, Neo4j | la boîte à outils modulaire de Walter White, pas un classeur figé / le carnet de terrain de Rick, des notes libres, pas un tableau rigide |
| DB document | Stocke des objets JSON-like à schéma flexible, pas de table fixe. | `{ _id: 1, nom: "Naruto", jutsus: ["Rasengan","Kage Bunshin"] }` | le dossier perso d'un survivant, avec autant de notes que nécessaire / la fiche libre d'un ninja, pas un formulaire standardisé |
| DB clé-valeur | Stocke une valeur accessible directement par une clé unique, ultra rapide. | `redis.set('combat:42', etat)` | le casier numéroté du vestiaire des Chevaliers Garo / la fréquence radio dédiée d'un survivant, accès direct |
| DB colonne large | Optimisée pour écrire et lire des volumes massifs répartis sur plusieurs machines. | Cassandra, ScyllaDB | l'armée entière de clones de Naruto répartie sur tout le champ de bataille / le réseau de distribution de Walter, étalé sur plusieurs villes |
| DB graphe | Stocke les relations comme structure de première classe, pas comme jointure. | `MATCH (a)-[:ALLIE_DE]->(b) RETURN b` | la carte des alliances entre clans ninja / le réseau de contacts de Michael à travers tout le pays |
| Eventual consistency | Garantie que la donnée finira par être cohérente partout, mais pas instantanément. | (comportement par défaut de beaucoup de DB distribuées) | la rumeur d'une attaque qui finit par atteindre tout le village / l'info qui circule lentement entre les groupes de survivants |
| Cache | Couche de stockage temporaire et rapide qui évite de recalculer ou re-requêter. | `redis.get('classement:balondor')` | le carnet de notes de Kakashi sur les ninjas déjà évalués / le tableau de bord déjà affiché du dashboard ultras |
| TTL (time to live) | Durée de vie d'une donnée en cache avant expiration automatique. | `redis.set('armure:99', etat, 'EX', 99)` | le compte à rebours de 99,9 secondes de l'armure Garo / le ticket de garde qui expire à la fin du tour |
| Cache HIT / MISS | HIT = la donnée était en cache. MISS = elle n'y était pas, il faut aller la chercher. | `if (cached) { /* HIT */ } else { /* MISS */ }` | trouver direct le bon jutsu dans le grimoire ouvert à la bonne page / devoir redescendre fouiller les archives de Fox River |
| Invalidation de cache | Suppression ou mise à jour du cache quand la donnée source change. | `redis.del('classement:balondor')` après un nouveau vote | jeter le brouillon de stratégie périmé après un nouveau plan / mettre à jour le tableau de menace du camp |
| Cache stampede | Des milliers de requêtes recalculent en même temps une donnée juste expirée. | (corrigé avec un lock, voir `04_redis_caching`) | toute la foule des ultras qui se précipite au même moment sur le live / tous les Chevaliers qui interrogent le réseau en même temps après une coupure |
| Cache-aside | Stratégie où l'appli vérifie le cache d'abord, sinon va en DB et remplit le cache. | voir `getClassement(saison)` dans `04_redis_caching` | demander à Kakashi avant d'aller fouiller les archives du village / vérifier le tableau de mission avant d'appeler le QG |
| Write-through | Stratégie où chaque écriture DB met aussi à jour le cache immédiatement. | écrire en DB + `redis.set` dans la même opération | mise à jour simultanée du rapport de mission et du tableau de bord du QG / double inscription immédiate sur le registre des Chevaliers |
| Driver (DB) | Bibliothèque bas niveau qui transporte les requêtes SQL brutes vers la DB. | `import { Pool } from 'pg'` | le talkie-walkie brut sans filtre entre Chevaliers / la ligne directe sans intermédiaire entre Michael et son contact |
| Query builder | Couche qui construit le SQL via des méthodes JS chaînées, lisible et typé. | `db.select().from(ninjas).where(...)` | le kit de construction modulaire de l'armure Garo / assembler une stratégie pièce par pièce, lisible à chaque étape |
| ORM (object-relational mapping) | Couche qui mappe des objets JS vers des lignes de DB, génère le SQL pour toi. | `prisma.ninja.findUnique({ where: { id: 1 } })` | le traducteur qui convertit les ordres de Kakashi en mouvements concrets / l'interprète qui gère toute la conversation entre deux mondes |
| Problème N+1 | Une requête initiale suivie d'une requête supplémentaire par élément, au lieu d'une seule optimisée. | boucle qui requête une fois par ninja au lieu d'un `include` | demander le dossier de chaque évadé un par un au lieu d'un rapport groupé / interroger chaque Chevalier séparément au lieu d'un seul appel radio collectif |
| Migration (DB) | Fichier versionné qui décrit un changement de schéma, appliqué dans un ordre connu. | `prisma migrate dev --name add_ninja_rank` | le plan de Michael, mis à jour version par version, jamais réécrit en vrac / le protocole Garo qui évolue de génération en génération, documenté |
| Pool de connexions | Ensemble de connexions DB réutilisées au lieu d'en ouvrir une nouvelle par requête. | `new Pool({ max: 10 })` | la flotte de motos de Daryl, réutilisées au lieu d'en voler une neuve à chaque sortie / le standard radio du QG Garo, lignes limitées et partagées |
| BLOB (binary large object) | Donnée binaire volumineuse stockée directement dans une colonne DB. | colonne `portrait BYTEA` en PostgreSQL | le portrait peint d'un Chevalier rangé directement dans le dossier / la vidéo de combat stockée dans le rapport de mission |
| Race condition (DB) | Deux opérations concurrentes qui se piétinent et produisent un résultat incohérent. | deux `UPDATE` simultanés sur le même JSON sans verrou | deux Chevaliers qui activent leur armure sur le même Horror en même temps, sans coordination / deux survivants qui modifient le même inventaire du camp au même instant |

---

## CE QUE TU DOIS RETENIR EN SORTANT DE CE MODULE

Une DB n'est jamais juste "l'endroit où on range les données". C'est un outil avec des compromis précis : SQL te donne l'intégrité et la rigueur au prix de la flexibilité, NoSQL te donne la flexibilité ou la vitesse au prix de garanties plus faibles, le cache te donne la vitesse au prix d'une fraîcheur relative que tu dois gérer activement.

Trois réflexes à garder à vie, peu importe le langage ou le framework du moment :

```
1. Avant un UPDATE/DELETE en prod : fais le SELECT équivalent d'abord
2. Avant de choisir une DB : regarde la forme de tes données ET de tes requêtes
3. Avant d'activer un ORM en confort : vérifie ce qui part vraiment en SQL (N+1, JOIN cachés)
```

Le reste (quel ORM est à la mode, quelle DB cloud est tendance) change tous les 2 ans. Ces trois réflexes ne changeront pas.
