# POURQUOI CE MODULE MÉRITE TON TEMPS : SCALABILITY

10 utilisateurs sur ton serveur, tout va bien. 10 millions d'utilisateurs sur le même serveur, sans rien changer à l'architecture : c'est l'effondrement garanti. Pas parce que ton code est mauvais. Parce qu'un seul serveur, une seule base de données, une seule instance, ça a toujours une limite physique, et cette limite arrive plus vite que tu ne le crois.

La scalabilité, c'est la discipline qui te dit comment grandir sans tout reconstruire au dernier moment, en panique, pendant que le système crashe sous la charge.

---

## PRÉREQUIS

Ce module suppose que tu maîtrises :
- une API REST fonctionnelle : voir `20_api_craft/`
- sécurité de base (rate limiting, auth) : voir `21_security/`
- comment les responsabilités se découpent entre services : voir `15_architecture_patterns/`
- bases de l'observabilité : voir `25_observability/` — ou lire les deux en parallèle

Sans API qui tourne et sans notion d'architecture, le load balancing et les queues de messages n'ont pas de contexte réel. Ces deux concepts sont des réponses à un problème qu'on ne voit que quand on a déjà un système en prod.

Si ces bases ne sont pas là : reviens ici après.

---

## 1) LE PROBLÈME QUE ÇA RÉSOUT

Un système conçu pour 100 utilisateurs simultanés ne se comporte pas juste "un peu moins bien" à 100 000 utilisateurs : il peut s'effondrer complètement si l'architecture n'a jamais anticipé cette croissance. Une seule instance de serveur a une limite de CPU et de mémoire. Une seule base de données a une limite de débit de requêtes. Sans stratégie de scalabilité, chaque pic de trafic devient un risque de panne totale.

Ce module donne les outils pour répartir la charge intelligemment : le load balancing (distribution du trafic entre plusieurs instances avec des stratégies comme round-robin ou least connections), le choix entre scale up (une machine plus puissante) et scale out (plus de machines, chacune normale), le rate limiting (limiter le nombre de requêtes par utilisateur pour éviter qu'un seul abus ne sature tout le système pour tout le monde), et les message queues (files de messages qui découplent un producteur d'un consommateur, pour absorber des pics sans tout traiter en synchrone et instantanément).

Le but n'est pas de scaler pour scaler : c'est de comprendre où ton système va casser en premier, et de mettre la bonne stratégie en place avant que ça arrive, pas après.

---

## 2) QUI SOUFFRE QUAND ÇA MANQUE

Le dev qui ne pense jamais à la scalabilité découvre le problème au pire moment possible : en plein pic de trafic réel (un lancement produit, un événement viral, un Black Friday), quand le serveur unique sature et que tous les utilisateurs voient des timeouts (délais d'attente dépassés) en même temps. Le système ne dégrade pas gracieusement : il tombe d'un coup, pour tout le monde simultanément.

Sans rate limiting, un seul utilisateur (ou un bot malveillant) peut saturer une API à lui seul en envoyant des milliers de requêtes par seconde, ce qui dégrade le service pour tous les utilisateurs légitimes, sans qu'aucune attaque sophistiquée n'ait été nécessaire.

Et sans message queue pour découpler les opérations lourdes, chaque requête qui déclenche un traitement long (envoi d'email, génération de rapport, traitement d'image) bloque directement le serveur pendant tout le traitement, ce qui ralentit TOUTES les autres requêtes en attente pendant ce temps.

---

## 3) OÙ ÇA APPARAÎT DANS UN VRAI SYSTÈME

```
trafic qui dépasse la capacité d'un seul serveur            --> load balancing       --> distribution sur plusieurs instances
besoin de plus de capacité serveur                          --> scale up vs scale out --> stratégie selon le contexte
utilisateur (ou bot) qui spam les requêtes                   --> rate limiting        --> protection sans bloquer les légitimes
opération lourde qui bloquerait le traitement synchrone       --> message queue        --> traitement découplé et asynchrone
pic de trafic soudain (lancement, événement viral)            --> architecture scalable --> absorption sans effondrement
```

La scalabilité n'apparaît pas uniquement sur les très grandes plateformes : même un projet de taille moyenne peut rencontrer un pic de trafic inattendu (une mention sur les réseaux sociaux, par exemple) qui révèle instantanément si l'architecture était prête ou non.

---

## 4) MODERNE, LEGACY, OU INTEMPOREL ?

Les principes (distribuer la charge, découpler les opérations lourdes, limiter les abus) sont intemporels. Ce qui a beaucoup évolué, c'est l'accessibilité de ces techniques : ce qui demandait autrefois une infrastructure complexe et coûteuse est aujourd'hui largement simplifié par les plateformes cloud modernes.

---

## 5) CE QUI A CHANGÉ AU FIL DES ANNÉES

Avant, scaler voulait souvent dire investir dans du matériel plus puissant (scale up), avec une limite physique évidente : il existe toujours une machine plus puissante, mais le coût augmente de façon disproportionnée par rapport au gain. Le scale out (multiplier les instances normales plutôt que viser une seule machine surpuissante) est devenu l'approche dominante avec la maturité du cloud, parce qu'il permet une croissance plus progressive et plus résiliente (la panne d'une seule instance parmi dix n'effondre pas tout le système).

Les message queues ont aussi gagné en accessibilité : des solutions managées par les fournisseurs cloud ont remplacé l'infrastructure maison complexe que ça demandait auparavant, rendant le découplage producteur/consommateur accessible même à des équipes plus petites.

---

## 6) NOYAU DUR DU MÉTIER ?

Central dans le mini-projet `06_ultras_dashboard`, qui combine `25_observability`, `24_scalability`, et `13_typescript` pour un système qui doit gérer des milliers d'utilisateurs connectés simultanément sans jamais tomber pendant un match en direct, ce qui rend la scalabilité une condition de survie du produit, pas un bonus technique.

---

## 7) POURQUOI ÇA MÉRITE ENCORE TON TEMPS DANS 5 ANS

Peu importe à quel point le matériel et le cloud deviennent puissants et accessibles, les volumes de données et de trafic augmentent toujours plus vite que la capacité brute d'une seule machine. La discipline de penser "comment ce système se comporte à 10x, 100x, 1000x le trafic actuel" reste une compétence d'architecture permanente, qui ne dépend d'aucune technologie précise.

---

## CE QUE TU DOIS RETENIR AVANT D'OUVRIR LE CHAPITRE 01

Un système qui marche à petite échelle peut s'effondrer brutalement à grande échelle si personne n'a anticipé la croissance. Ça casse de trois façons sans cette discipline : serveur unique saturé, abus non limité qui dégrade tout, opérations lourdes qui bloquent tout le système. Ce problème reste permanent peu importe la puissance du matériel disponible.

Maintenant, ouvre `01_load_balancing.md`. Et commence à penser ton système pour 10 fois la charge qu'il a aujourd'hui.
